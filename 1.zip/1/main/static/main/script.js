
// Konami code

const code=["Up","Up","Down","Down","Left","Right","Left","Right","B","A"];
const code2=["O","U","E","S","T","C","H","A","R","L","I","E"];
var indexkonami=0;
var indexcharlie=0;
function konami_game(){
    window.open("jeux2","_self")
}
function charlie_game(){
    window.open("charlie","_self")
}
function konami(key){
    if(key==code[indexkonami]){
        indexkonami++;
        if(indexkonami==10){
            konami_game();
            indexkonami=0;
        }
    }
    else indexkonami=0;
}
function charlie(key){
    if(key==code2[indexcharlie]){
        indexcharlie++;
        if(indexcharlie==12){
            charlie_game();
            indexcharlie=0;
        }
    }
    else indexcharlie=0;
}
document.addEventListener('keydown',(event)=>{
    var name=event.key;
    var namemaj=name.toUpperCase();
    switch(name)
    {
        case "ArrowUp": konami("Up"); break;
        case "ArrowDown": konami("Down"); break;
        case "ArrowLeft": konami("Left"); break;
        case "ArrowRight": konami("Right"); break;
    }
    switch(namemaj){
        case "B": konami("B"); break;
        case "A": konami("A"); break;
    }
    switch(namemaj){
        case "O": konami("O"); break;
        case "U": konami("U"); break;
        case "E": konami("E"); break;
        case "S": konami("S"); break;
        case "T": konami("T"); break;
        case "C": konami("C"); break;
        case "H": konami("H"); break;
        case "A": konami("A"); break;
        case "R": konami("R"); break;
        case "L": konami("L"); break;
        case "I": konami("I"); break;
        case "E": konami("E"); break;
    }
    
})
