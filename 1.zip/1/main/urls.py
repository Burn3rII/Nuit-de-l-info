from django.urls import path
from . import views

app_name = "main"
urlpatterns = [
    path("home", views.home, name="home"),
    path("infos", views.infos, name="infos"),
    path("jeux", views.jeux, name="jeux"),
    path("jeux2", views.jeux2, name="jeux2"),
    path("charlie",views.charlie,name="charlie"),
]
